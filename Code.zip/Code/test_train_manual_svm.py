import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
import pickle
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
m=[]
#DATA_PATH="../data" # current directory
df = pd.read_csv("/home/pavithra/project/feat.csv")
y=df.iloc[:,:-59].values
print (y.shape)

x=df.ix[:,1:].values
print (x.shape)

from sklearn.model_selection import train_test_split

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 1/3, random_state = 49)
#print (x_train.shape)
#print (y_train.shape)
print('\n')
print('training..')
print('\n')

"""
clf = SVC()
clf.fit(x_train,y_train)
filename = 'training_svm.sav'
pickle.dump(clf, open(filename, 'wb'))
print('\n')

"""
print ('********Predicted value******************')
#pred=clf.predict(x_test)

loaded_model = pickle.load(open('training_svm.sav', 'rb'))
pred=loaded_model.predict(x_test)
print (pred)
print('\n')


print ("********Expected value******************")
print (y_test)

print('\n')
print("***********Accuracy**********************")
#print ((accuracy_score(y_test, pred)))

acc=(accuracy_score(y_test, pred))
ac=acc*100
print ("{0:.2f}".format(ac),'%')
print('\n')

print('************Confusion Matrix**************')
con=confusion_matrix(y_test, pred)
print(con)

tp = con[0][0] 
fp = con[0][1] 
fn = con[1][0] 
tn = con[1][1]
precision = tp/(tp+fp)
recall = tp/(tp+fn)
fmes=(2*recall*precision)/(recall+precision)
print('\n')
print('Precision: ',precision)
print('Recall: ',recall) 
print('Fmeasure: ',fmes)
print('\n')

