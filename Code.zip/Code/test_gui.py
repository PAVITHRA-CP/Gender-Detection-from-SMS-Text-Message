import nltk
import csv
import re
from nltk.tag import pos_tag
import csv

from nltk.corpus import stopwords
import re
from collections import Counter
from nltk.stem.wordnet import WordNetLemmatizer
from nltk import word_tokenize
from nltk.tag import pos_tag
import string
from numpy import genfromtxt
import glob
import ntpath
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
import pickle
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
import warnings
import tkinter
from tkinter import *
import os              #used to call system.
import os.path 
from tkinter import messagebox
from tkinter import filedialog
from PIL import Image, ImageTk

f=[]
g=[]
greetings = ['Hey','Hey man','Hi','Hello','How\'s it going?','How are you doing?','What\'s up?', 'What\'s new?', 'What\'s going on?','How\'s everything?', 'How are things?', 'How\'s life?','How\'s your day?', 'How\'s your day going?','Good to see you', 'Nice to see you','Long time no see', 'It\'s been a while', 'Good morning', 'Good afternoon', 'Good evening', 'It\'s nice to meet you', 'Pleased to meet you', 'How have you been?', 'How do you do?', 'Yo!', 'Are you OK?', 'You alright?', 'Alright mate?', 'Howdy!', 'Sup?', 'Whazzup?', 'G\'day mate!','Hiya!','How are you?']

farewell = ['bye', 'bye bye!',' See you later', 'See you soon','Talk to you later', 'I\'ve got to get going', 'I must be going', 'Take it easy', 'I\'m off', 'Goodbye','Have a nice day', 'Have a good', ' I look forward to our next meeting', ' Take care', 'It was nice to see you again', 'It was nice seeing you', 'Good night', 'Later', 'Laters','Catch you later','Peace', 
'Peace out', 'I\'m out' ,'I\'m out of here', 'I gotta jet', 'I gotta take off', 'I gotta hit the road' ,'I gotta head out']

#.......................................................................................................................................
def character(i):
	chara = len(i)
	char_count=re.findall(r"[A-Za-z]+",i)
	str_char=''.join(char_count)
	letters = len(str_char)
	upp=re.findall(r'[A-Z]',i)
	str_up=''.join(upp)
	upper=len(str_up)
	sp =  re.findall('[\w]', i)
	str_sp = ''.join(sp)
	spcl=len(str_sp)
	dig_count=re.findall(r"[0-9]+",i)
	str_dig=''.join(dig_count)
	dig=len(str_dig)
	s = i.count(' ')
	f.append(chara)
	f.append(letters)
	f.append(upper)
	f.append(spcl)
	f.append(dig)
	f.append(s)
		
def word(i):
	sht = []
	ln = []
	
	wrd = len(i.split())
	wrds_lst = i.split()
	for word in wrds_lst:
		if len(word)<=3:
			sht += [word]
		if len(word)>=6:
			ln +=[word]
	shrt=len(sht)
	lng=len(ln)
	del sht[:]
	del ln[:]
	avg = sum(len(word) for word in wrds_lst) / len(wrds_lst)
	avg_lng="{0:.2f}".format(avg)
	f.append(wrd)
	f.append(shrt)
	f.append(lng)
	f.append(avg_lng)

def syntactic(i):
	qtn = i.count("'")
	comm = i.count(',')
	ex = i.count('!')
	if ex == 1:
		sin_exclm = ex
		mul_exclm = 0
			
	else:
		mul_exclm = ex
		sin_exclm = 0
	qs = i.count('?')
	if qs == 1:
		sin_qstn = qs
		mul_qstn = 0
			
	else:
		mul_qstn = qs
		sin_qstn = 0
	do=i.count('.')
		
	eli=i.count('...')
		
	co=i.count(':')
		
	sem=i.count(';')
		
	f.append(qtn)
	f.append(comm)
	f.append(sin_exclm)
	f.append(mul_exclm)
	f.append(sin_qstn)
	f.append(mul_qstn)
	f.append(do)
	f.append(eli)
	f.append(co)
	f.append(sem)

def structural(i):
	
	if i[0].isupper():
		strt_upper= 1
		beg_low = 0
	else:
		beg_low = 1
		strt_upper = 0
	if any(word in i for word in farewell):
		fare = 1
	else:
		fare = 0
	if any(word in i for word in greetings):
		greet = 1
	else:
		greet = 0
	f.append(strt_upper)
	f.append(beg_low)
	f.append(fare)
	f.append(greet)


def functional(i):
	p=[]
	
	pos = pos_tag(word_tokenize(i))
	for i,j in pos:
		p.append(j)
	cc=p.count('CC')
	cd=p.count('CD')
	dt=p.count('DT')
	ex=p.count('EX')
	fw=p.count('FW')
	In=p.count('IN')
	jj=p.count('JJ')
	jjr=p.count('JJR')
	jjs=p.count('JJS')
	ls=p.count('LS')
	md=p.count('MD')
	nn=p.count('NN')
	nns=p.count('NNS')
	nnp=p.count('NNP')
	nnps=p.count('NNPS')
	pdt=p.count('PDT')
	pos=p.count('POS')
	prp=p.count('PRP')
	prpd=p.count('PRP$')
	rb=p.count('RB')
	rbr=p.count('RBR')
	rbs=p.count('RBS')
	rp=p.count('RP')
	to=p.count('TO')
	uh=p.count('UH')
	vb=p.count('VB')
	vbd=p.count('VBD')
	vbg=p.count('VBG')
	vbn=p.count('VBN')
	vbp=p.count('VBP')
	vbz=p.count('VBZ')
	wdt=p.count('WDT')
	wp=p.count('WP')
	wpd=p.count('WP$')
	wrb=p.count('WRB')
	del p[:]
	f.append(cc)
	f.append(cd)
	f.append(dt)
	f.append(ex)
	f.append(fw)
	f.append(In)
	f.append(jj)
	f.append(jjr)
	f.append(jjs)
	f.append(ls)
	f.append(md)
	f.append(nn)
	f.append(nns)
	f.append(nnp)
	f.append(nnps)
	f.append(pdt)
	f.append(pos)
	f.append(prp)
	f.append(prpd)
	f.append(rb)
	f.append(rbr)
	f.append(rbs)
	f.append(rp)
	f.append(to)
	f.append(uh)
	f.append(vb)
	f.append(vbd)
	f.append(vbg)
	f.append(vbn)
	f.append(vbp)
	f.append(vbz)
	f.append(wdt)
	f.append(wp)
	f.append(wpd)
	f.append(wrb)

def pred(msg):

	character(msg)
	word(msg)
	syntactic(msg)
	structural(msg)
	functional(msg)


	fe = np.array(f)
	fe1 = np.reshape(fe,(1, -1))

	df = pd.read_csv("/home/pavithra/project/feat.csv")
	y=df.iloc[:,:-59].values

	x=df.ix[:,'charcount':].values

	x_train = x
	y_train = y
	x_test = fe1


	"""
	clf = SVC()
	clf.fit(x_train,y_train)

	filename = 'test_svm.sav'
	pickle.dump(clf, open(filename, 'wb'))
	"""
	loaded_model = pickle.load(open('test_svm.sav', 'rb'))
	pred=loaded_model.predict(x_test)
	print('\n')
	print ('********predicted value******************')
	#pred=clf.predict(x_test)
	#print pred

	p=pred[0]
	if p==1:
		prd1='FEMALE'
	else:
		prd1='MALE'
	ResultBox.delete(1.0, END)
	ResultBox.insert(END,prd1)
	s=''

def predict():
	global s
	s=E1.get()
	pred(s)

def check():
	E1.delete(0, END)
	ResultBox.delete(1.0, END)
	window.destroy()
	os.system('clear')
	cmd4="python3 test_gui.py "
	os.system(cmd4)

def window1():
	global E1
	global ResultBox
	global window
	window = tkinter.Tk()
	window.title('GENDER IDENTIFICATION FROM SMS TEXT MESSAGE')
	width=500
	height=400
	window.geometry("500x400")
	window.resizable(width=True, height=True)

	image = Image.open("images.jpeg")
	if image.size != (width, height):
	    image = image.resize((width, height), Image.ANTIALIAS)
	image = ImageTk.PhotoImage(image)
	bg_label = tkinter.Label(window, image = image)
	bg_label.place(x=0, y=0, relwidth=1, relheight=1)
	bg_label.image = image


	L1 = Label(window, text="Gender Identification",fg='red',padx = 1, pady = 5)
	labelfont = ('times', 15, 'bold')
	L1.config(font=labelfont)
	L1.place(x=125, y=30)

	L2 = Label(window, text="Enter the Message :",fg='green',padx = 1, pady = 5)
	L2.place(x=25, y=100)
	labelfont = ('times', 13, 'bold')
	L2.config(font=labelfont)

	E1 = Entry(window, bd =8,width=35)
	E1.place(x=180, y=100)


	FeatureBut = Button(window, text='Predict Gender',command = predict, highlightcolor='white',bg='orange')
	FeatureBut.place(x=100, y=200)

	FeatureBut1 = Button(window, text='Check More',command = check, highlightcolor='white',bg='orange')
	FeatureBut1.place(x=260, y=200)


	ResultBox = Text(window, height=3, width=50)
	ResultBox.place(x=90, y=300)

	window.mainloop()				
window1()
