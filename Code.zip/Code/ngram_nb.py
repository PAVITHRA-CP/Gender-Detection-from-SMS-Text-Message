from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd
import csv
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
import pickle
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB


vect = TfidfVectorizer(ngram_range=(1,2),max_features=100)
with open("msg1.csv",'rb')as inp:
	dtm = vect.fit_transform(inp)
	#print dtm

x=pd.DataFrame(dtm.toarray(), columns=vect.get_feature_names()) 
z=x[:40935]
#print z

print (z.shape)



df = pd.read_csv("/home/pavithra/project/feat.csv")
y=df.iloc[:,:-59].values
#print y

#z=y[:40918]
#print (z.shape)
print (y.shape)


from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(z, y, test_size = 1/3, random_state = 42)
#print (y_test)

clf = GaussianNB()
clf.fit(x_train,y_train)
print('\n')
print ('********************** Predicted value ********************')
pred=clf.predict(x_test)
print (pred)
print ("******************** Correct value **************************")
print (y_test)
print ('\n')
print("************** acucracy is ************************")
acc=(accuracy_score(y_test, pred))
ac=acc*100
print ("{0:.2f}".format(ac),'%')
print('\n')
print('************Confusion Matrix**************')
con=confusion_matrix(y_test, pred)
print(con)

tp = con[0][0] 
fp = con[0][1] 
fn = con[1][0] 
tn = con[1][1]
precision = tp/(tp+fp)
recall = tp/(tp+fn)
fmes=(2*recall*precision)/(recall+precision)
print('\n')
print('Precision: ',precision)
print('Recall: ',recall) 
print('Fmeasure: ',fmes)
print('\n')




