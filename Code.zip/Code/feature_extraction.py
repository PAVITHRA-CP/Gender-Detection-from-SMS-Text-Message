#!/usr/bin/python
# -*- coding: utf_8 -*-

# IMPORTED FILES
import os,sys
import csv
import nltk
from nltk.corpus import stopwords
import re
from collections import Counter
from nltk.stem.wordnet import WordNetLemmatizer
from nltk.tokenize import sent_tokenize
from nltk import word_tokenize
from nltk.tag import pos_tag
import string
from numpy import genfromtxt
import glob
import ntpath

reload(sys)
sys.setdefaultencoding('utf8')
#..................................................................................................................
lst = []
malelst = []
femalelst = []
mlst = []
flst = []
ml = []
fl = []
male_stem = []
female_stem = []
label = []
male_ngram = ['m_n']
female_ngram = ['f_n']
#................................................................................................................
feat = ['charcount']
letters = ['letter']
upper = ['upper']
spcl = ['spcl']
dig = ['digts']
s = ['space']
#..................................................................................................................

wrd = ['wrds']
lng = ['long']
shrt = ['short']
avg_lng = ['avg lngth']
#..................................................................................................................
qtn = ['qutn']
comm = ['commas']
sin_exclm = ['sin_exclmn']
mul_exclm = ['mul_exclmn']
sin_qstn = ['sin_qstn']
mul_qstn = ['mul_qstn']
sin_dot=['sin_dot']
ellipse = ['ellipse']
colon=['colon']
semi_col=['semi_colon']

#........................................................................................................................................
strt_upper= ['strt_upper']
beg_low = ['beg_lower']
greet = ['greeting']
fare = ['farewell']
wrd_sen = ['average words']

greetings = ['Hey','Hey man','Hi','Hello','How\'s it going?','How are you doing?','What\'s up?', 'What\'s new?', 'What\'s going on?','How\'s everything?', 'How are things?', 'How\'s life?','How\'s your day?', 'How\'s your day going?','Good to see you', 'Nice to see you','Long time no see', 'It\'s been a while', 'Good morning', 'Good afternoon', 'Good evening', 'It\'s nice to meet you', 'Pleased to meet you', 'How have you been?', 'How do you do?', 'Yo!', 'Are you OK?', 'You alright?', 'Alright mate?', 'Howdy!', 'Sup?', 'Whazzup?', 'G\'day mate!','Hiya!','How are you?']

farewell = ['bye', 'bye bye!',' See you later', 'See you soon','Talk to you later', 'I\'ve got to get going', 'I must be going', 'Take it easy', 'I\'m off', 'Goodbye','Have a nice day', 'Have a good', ' I look forward to our next meeting', ' Take care', 'It was nice to see you again', 'It was nice seeing you', 'Good night', 'Later', 'Laters','Catch you later','Peace', 
'Peace out', 'I\'m out' ,'I\'m out of here', 'I gotta jet', 'I gotta take off', 'I gotta hit the road' ,'I gotta head out']
#...............................................................................................................................
cc1=['cc']
cd1=['cd']
dt1=['dt']
ex1=['ex']
fw1=['fw']
In1=['in']
jj1=['jj']
jjr1=['jjr']
jjs1=['jjs']
ls1=['ls']
md1=['md']
nn1=['nn']
nns1=['nns']
nnp1=['nnp']
nnps1=['nnps']
pdt1=['pdt']
pos1=['pos']
prp1=['prp']
prpd1=['prp$']
rb1=['rb']
rbr1=['rbr']
rbs1=['rbs']
rp1=['rp']
to1=['to']
uh1=['uh']
vb1=['vb']
vbd1=['vbd']
vbg1=['vbg']
vbn1=['vbn']
vbp1=['vbp']
vbz1=['vbz']
wdt1=['wdt']
wp1=['wp']
wpd1=['wp$']
wrb1=['wrb']
#.......................................................................................................................................
stop = set(stopwords.words('english'))
lmtzr = WordNetLemmatizer()

#.......................................................................................................................................
# CHARACTER BASED 
def character(lst):
	for i in lst:
		chara = len(i)
		feat.append(chara)
		
		char_count=re.findall(r"[A-Za-z]+",i)
    		str_char=''.join(char_count)
		letters.append(len(str_char))
		upp=re.findall(r'[A-Z]',i)
		str_up=''.join(upp)
		upper.append(len(str_up))
		sp =  re.findall('[\w]', i)
		str_sp = ''.join(sp)
		spcl.append(len(str_sp))
		dig_count=re.findall(r"[0-9]+",i)
    		str_dig=''.join(dig_count)
		dig.append(len(str_dig))
		s.append(i.count(' '))

# WORD BASED
def word(lst):
	sht = []
	ln = []
	for i in lst:
		wrd.append(len(i.split()))
		wrds_lst = i.split()
		for word in wrds_lst:
			if len(word)<=3:
				sht += [word]
			if len(word)>=6:
				ln +=[word]
		shrt.append(len(sht))
		lng.append(len(ln))
		del sht[:]
		del ln[:]
		avg = sum(len(word) for word in wrds_lst) / len(wrds_lst)
		avg_lng.append("{0:.2f}".format(avg))

#SYNTACTIC
def syntactic(lst):
	for i in lst:
		qtn.append(i.count("'"))
		comm.append(i.count(','))
		ex = i.count('!')
		if ex == 1:
			sin_exclm.append(ex)
			mul_exclm.append(0)
			
		else:
			mul_exclm.append(ex)
			sin_exclm.append(0)
		qs = i.count('?')
		if qs == 1:
			sin_qstn.append(qs)
			mul_qstn.append(0)
			
		else:
			mul_qstn.append(qs)
			sin_qstn.append(0)
		do=i.count('.')
		sin_dot.append(do)
		eli=i.count('...')
		ellipse.append(eli)
		co=i.count(':')
		colon.append(co)
		sem=i.count(';')
		semi_col.append(sem)

# STRUCTURAL
def structural(lst):
	for i in lst:
		if i[0].isupper():
			strt_upper.append(1)
			beg_low.append(0)
		else:
			beg_low.append(1)
			strt_upper.append(0)
		if any(word in i for word in farewell):
			fare.append(1)
		else:
			fare.append(0)
		if any(word in i for word in greetings):
			greet.append(1)
		else:
			greet.append(0)
		words = i.split()
		
		sent_tokenize_list = sent_tokenize(i)

		aw= float(len(words) / len(sent_tokenize_list))
		wrd_sen.append(aw)
	

# FUNCTIONAL
def functional(lst):
	p=[]
	for i in lst:
		pos = pos_tag(word_tokenize(i))
        	for i,j in pos:
			p.append(j)
		cc=p.count('CC')
		cd=p.count('CD')
		dt=p.count('DT')
		ex=p.count('EX')
		fw=p.count('FW')
		In=p.count('IN')
		jj=p.count('JJ')
		jjr=p.count('JJR')
		jjs=p.count('JJS')
		ls=p.count('LS')
		md=p.count('MD')
		nn=p.count('NN')
		nns=p.count('NNS')
		nnp=p.count('NNP')
		nnps=p.count('NNPS')
		pdt=p.count('PDT')
		pos=p.count('POS')
		prp=p.count('PRP')
		prpd=p.count('PRP$')
		rb=p.count('RB')
		rbr=p.count('RBR')
		rbs=p.count('RBS')
		rp=p.count('RP')
		to=p.count('TO')
		uh=p.count('UH')
		vb=p.count('VB')
		vbd=p.count('VBD')
		vbg=p.count('VBG')
		vbn=p.count('VBN')
		vbp=p.count('VBP')
		vbz=p.count('VBZ')
		wdt=p.count('WDT')
		wp=p.count('WP')
		wpd=p.count('WP$')
		wrb=p.count('WRB')

		cc1.append(cc)
		cd1.append(cd)
		dt1.append(dt)
		ex1.append(ex)
		fw1.append(fw)
		In1.append(In)
		jj1.append(jj)
		jjr1.append(jjr)
		jjs1.append(jjs)
		ls1.append(ls)
		md1.append(md)
		nn1.append(nn)
		nns1.append(nns)
		nnp1.append(nnp)
		nnps1.append(nnps)
		pdt1.append(pdt)
		pos1.append(pos)
		prp1.append(prp)
		prpd1.append(prpd)
		rb1.append(rb)
		rbr1.append(rbr)
		rbs1.append(rbs)
		rp1.append(rp)
		to1.append(to)
		uh1.append(uh)
		vb1.append(vb)
		vbd1.append(vbd)
		vbg1.append(vbg)
		vbn1.append(vbn)
		vbp1.append(vbp)
		vbz1.append(vbz)
		wdt1.append(wdt)
		wp1.append(wp)
		wpd1.append(wpd)
		wrb1.append(wrb)
		del p[:]
#.......................................................................................................................................

# DATA CLEANING
print "feature extraction.."
with open('convertcsv.csv', 'rb') as inp, open('csvedited.csv', 'wb') as out:
    writer = csv.writer(out)
    m = open("msg.csv","w")
    p=open("msg1.csv",'w')
    m.write('gender')
    m.write('\n')
    for row in csv.reader(inp):
      if not 'VCARD' in row[1]:
       if not re.search(u'[\x80-\xbf]', row[1]):
        if row[7] == "male":
            writer.writerow(row)
	    malelst.append(row[1])
	    lst.append(row[1])
	    line ='0'+'\n'
	    m.write(line)
	    label.append(0)
	    mssg=row[1]+'\n'
	    p.write(mssg)
	if row[7] == "female":
            writer.writerow(row)
	    lst.append(row[1])
	    femalelst.append(row[1])
	    line = '1'+'\n'
	    m.write(line)
	    label.append(1)
	    mssg=row[1]+'\n'
	    p.write(mssg)
    m.close()
    inp.close()
    out.close()
   
#.......................................................................................................................................

mlst = [element.lower() for element in malelst]
flst = [element.lower() for element in femalelst]

#.......................................................................................................................................
   
m=open("male_wrds.txt","w")
for lis in mlst:
	ml = lis.split()
	for item in ml:
	   if item not in stop:
		m.write("%s\n" % item)
		i = item.decode('utf8')
		male_stem.append(lmtzr.lemmatize(i))
m.close()
male_ngram.append(zip(*[male_stem[i:] for i in range(2)]))



m=open("female_wrds.txt","w")
for lis in flst:
	fl = lis.split()
    	for item in fl:
	   if item not in stop:
		m.write("%s\n" % item)
		i = item.decode('utf8')
		female_stem.append(lmtzr.lemmatize(i))
m.close()
female_ngram.append(zip(*[female_stem[i:] for i in range(2)]))

#......................................................................................................................................

# FEATURE EXTRACTION
character(lst)
word(lst)
syntactic(lst)
structural(lst)
functional(lst)

#.......................................................................................................................................

# FEATURE SET 
with open("msg.csv",'r') as doc,open('feat.csv','w') as feature:
	 for line, new, let, up, sp, dg, spc, wd, lg, st, avg, qt, com, sin, mul, qs, qs1, dot, elli, col, semi, beg_up, beg_lw, gree, far, cc, cd, dt, ex, fw, In, jj, jjr, jjs, ls, md, nn, nns, nnp, nnps, pdt, pos, prp, prpd, rb, rbr, rbs, rp, to, uh, vb, vbd, vbg, vbn, vbp, vbz, wdt, wp, wpd, wrb in zip(doc, feat, letters, upper, spcl, dig, s, wrd, lng, shrt, avg_lng, qtn, comm, sin_exclm, mul_exclm, sin_qstn, mul_qstn, sin_dot, ellipse, colon, semi_col, strt_upper, beg_low, greet, fare, cc1, cd1, dt1, ex1, fw1, In1, jj1, jjr1, jjs1, ls1, md1, nn1, nns1, nnp1, nnps1, pdt1, pos1, prp1, prpd1, rb1, rbr1, rbs1, rp1, to1, uh1, vb1, vbd1, vbg1, vbn1, vbp1, vbz1, wdt1, wp1, wpd1, wrb1):
		 new_line = line.rstrip('\n') + ',' + str(new) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(let) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(up) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(sp) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(dg) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(spc) + '\n'

		 new_line = new_line.rstrip('\n') + ',' + str(wd) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(lg) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(st) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(avg) + '\n'

		 new_line = new_line.rstrip('\n') + ',' + str(qt) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(com) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(sin) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(mul) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(qs) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(qs1) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(dot) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(elli) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(col) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(semi) + '\n'

		 new_line = new_line.rstrip('\n') + ',' + str(beg_up) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(beg_lw) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(gree) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(far) + '\n'
 		 
		 new_line = new_line.rstrip('\n') + ',' + str(cc) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(cd) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(dt) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(ex) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(fw) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(In) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(jj) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(jjr) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(jjs) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(ls) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(md) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(nn) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(nns) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(nnp) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(nnps) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(pdt) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(pos) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(prp) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(prpd) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(rb) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(rbr) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(rbs) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(rp) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(to) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(uh) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(vb) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(vbd) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(vbg) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(vbn) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(vbp) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(vbz) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(wdt) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(wp) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(wpd) + '\n'
		 new_line = new_line.rstrip('\n') + ',' + str(wrb) + '\n'
 		 feature.write(new_line)


